class Config:
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = ''  # Default XAMPP password is empty
    MYSQL_DB = 'medilog_db'
    SECRET_KEY = 'your-secret-key-here'  # Change this for production